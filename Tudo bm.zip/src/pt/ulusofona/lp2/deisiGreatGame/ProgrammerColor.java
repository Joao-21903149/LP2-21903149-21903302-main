package pt.ulusofona.lp2.deisiGreatGame;

public enum ProgrammerColor {
    BLUE,
    GREEN,
    PURPLE,
    BROWN,
}
