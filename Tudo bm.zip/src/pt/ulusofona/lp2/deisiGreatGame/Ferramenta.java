package pt.ulusofona.lp2.deisiGreatGame;

public class Ferramenta extends Items {
    String descricao;


    public Ferramenta() {

    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao() {
        switch(super.titulo){
            case "Herança" -> {
                this.descricao = "O simoes tem uma herança";
            }
            case "Programação funcional" ->{
                this.descricao = "O simoes tem um programa funcional";
            }
            case "Testes unitários" -> {
                this.descricao = "O simoes tem um teste unitário";
            }
            case "Tratamento de Excepções" -> {
                this.descricao = "O simoes tem um Tratamento de Excepções";
            }
            case "IDE" -> {
                this.descricao =  "O simoes tem um IDE";
            }
            case "Ajuda Do Professor" -> {
                this.descricao = "O simoes tem Ajuda Do Professor";
            }
        }
    }

    @Override
    public String toString() {
        return "Ferramenta{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", pos=" + pos +
                '}';
    }
}
