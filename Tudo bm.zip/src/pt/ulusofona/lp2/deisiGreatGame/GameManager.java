package pt.ulusofona.lp2.deisiGreatGame;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.*;
import java.util.List;


public class GameManager {

    List<Programmer> programmers;
    Programmer[] programmersTurn;
    int programmerTurnPos;

    ArrayList<String> colors;
    int boardSize;
    boolean playing;
    int nrTurnos;

    List<Abismo> abismos;
    List<Ferramenta> ferramentas;

    HashMap<Integer,Abismo> abismosHashMap= new HashMap<Integer,Abismo>();
    HashMap<Integer,Ferramenta> ferramentasHashMap = new HashMap<Integer,Ferramenta>();


    public GameManager() {
        programmers = new ArrayList<Programmer>();
        colors = new ArrayList<String>();
        this.playing = true;
        abismos = new ArrayList<Abismo>();
        ferramentas = new ArrayList<Ferramenta>();

    }

/*
    public boolean createInitialBoard(String[][] playerInfo, int boardSize){
        this.programmers = new ArrayList<Programmer>();
        this.colors = new ArrayList<String>();
        int programmerTurnPos = 0;
        this.boardSize = 0;
        this.nrTurnos = 1;
        this.playing = true;

        boolean correct = true;
        int size = playerInfo.length;
        if((size > 4 || size < 2) || boardSize < size * 2 ){
            return false;

        }
        for(String[] x : playerInfo){
            boolean insert = true;
            HashMap<String,Integer> mapProgrammerToColor = new HashMap<String,Integer>();
            Programmer pNew = new Programmer();
            for(int i = 0; i < 4 ; i++) {
                switch (i) {
                    case 0: {
                        if (!programmers.isEmpty()) {
                            for (Programmer p : programmers) {
                                if (p.id == Integer.parseInt(x[i])) {
                                    return false;

                                }
                            }
                        }
                        if(Integer.parseInt(x[i]) < 0){
                            return false;

                        }
                        pNew.id = Integer.parseInt(x[i]);
                        break;

                    }
                    case 1: {
                        if (x[i] == null || x[i].isEmpty()) {
                            correct = false;

                            insert = false;
                        }
                        pNew.name = x[i];
                        break;
                    }
                    case 2: {
                        String[] result = x[i].split(";");
                        ArrayList<String> listaResult = new ArrayList<String>();
                        for(String s : result)
                        {
                            listaResult.add(s);
                        }
                        Collections.sort(listaResult);
                        pNew.linguages = listaResult;
                        break;

                    }
                    case 3: {

                        if (colors.contains(x[i])) {
                            return false;


                        } else {
                            colors.add(x[i]);
                        }
                        boolean z = false;
                        switch (x[i]) {
                            case "Purple" -> pNew.setColor(ProgrammerColor.PURPLE);
                            case "Green" -> pNew.setColor(ProgrammerColor.GREEN);
                            case "Brown" -> pNew.setColor(ProgrammerColor.BROWN);
                            case "Blue" -> pNew.setColor(ProgrammerColor.BLUE);
                            default -> z = true;
                        }
                        if(z){
                            return false;
                        }
                        break;
                    }
                }
            }

            programmers.add(pNew);

        }
        this.boardSize = boardSize;
        programmersTurn = new Programmer[programmers.size()];
        orderPlayers();

        return correct;
    }
 */

    public boolean createInitialBoard(String[][] playerInfo, int worldSize, String[][] abyssesAndTools) {
        this.programmers = new ArrayList<Programmer>();
        this.colors = new ArrayList<String>();
        int programmerTurnPos = 0;
        this.boardSize = worldSize;
        this.nrTurnos = 1;
        this.playing = true;

        boolean correct = true;
        int size = playerInfo.length;
        if((size > 4 || size < 2) || boardSize < size * 2 ){
            return false;

        }
        for(String[] x : playerInfo) {
            System.out.println(Arrays.toString(x));
            boolean insert = true;
            HashMap<String, Integer> mapProgrammerToColor = new HashMap<String, Integer>();
            Programmer pNew = new Programmer();
            for (int i = 0; i < 4; i++) {
                switch (i) {
                    case 0: {
                        if (!programmers.isEmpty()) {
                            for (Programmer p : programmers) {
                                if (p.getId() == Integer.parseInt(x[i])) {
                                    return false;

                                }
                            }
                        }
                        if (Integer.parseInt(x[i]) < 0) {
                            return false;

                        }
                        pNew.setId(Integer.parseInt(x[i]));
                        break;

                    }
                    case 1: {
                        if (x[i] == null || x[i].isEmpty()) {
                            correct = false;

                            insert = false;
                        }
                        pNew.setName(x[i]);
                        break;
                    }
                    case 2: {
                        String[] result = x[i].split(";");
                        ArrayList<String> listaResult = new ArrayList<String>();
                        for (String s : result) {
                            listaResult.add(s);
                        }
                        Collections.sort(listaResult);
                        pNew.setLinguages(listaResult);
                        break;

                    }
                    case 3: {

                        if (colors.contains(x[i])) {
                            return false;


                        } else {
                            colors.add(x[i]);
                        }
                        boolean z = false;
                        switch (x[i]) {
                            case "Purple" -> pNew.setColor(ProgrammerColor.PURPLE);
                            case "Green" -> pNew.setColor(ProgrammerColor.GREEN);
                            case "Brown" -> pNew.setColor(ProgrammerColor.BROWN);
                            case "Blue" -> pNew.setColor(ProgrammerColor.BLUE);
                            default -> z = true;
                        }
                        if (z) {
                            return false;
                        }
                        break;
                    }
                }
            }

            programmers.add(pNew);
        }
        programmersTurn = new Programmer[programmers.size()];
        orderPlayers();


        boolean isAbismo = true;
        for (String[] info : abyssesAndTools) {
            System.out.println(Arrays.toString(info));
            Abismo a = new Abismo();
            Ferramenta f = new Ferramenta();
            for (int i = 0; i < 3; i++) {
                switch (i) {
                    case 0: {

                        if (info[i].equals("0")) {
                            isAbismo = true;
                        } else if (info[i].equals("1")) {
                            isAbismo = false;
                        } else {
                            return false;
                        }
                        break;
                    }
                    case 1: {
                        if (isAbismo) {
                            a.setId(Integer.parseInt(info[i]));
                            a.setTitulo(getTituloAbismo(a.getId()));
                            if (a.getTitulo().equals("404")) {
                                return false;
                            }
                        } else {
                            f.setId(Integer.parseInt(info[i]));
                            f.setTitulo(getTituloFerramenta(f.getId()));
                            if (f.getTitulo().equals("404")) {
                                return false;
                            }
                        }
                        break;
                    }
                    case 2: {
                        if(Integer.parseInt(info[i]) <= 0 || Integer.parseInt(info[i]) >= worldSize){
                            return false;
                        }
                        if (isAbismo) {
                            a.setPos(Integer.parseInt(info[i]));
                        } else {
                            f.setPos(Integer.parseInt(info[i]));
                        }
                        break;
                    }
                }
            }
            if(isAbismo){
                this.abismos.add(a);
            }else{
                this.ferramentas.add(f);
            }
        }

        for(Abismo a : this.abismos){
            System.out.println(a.toString());
        }
        for(Ferramenta f : this.ferramentas){
            System.out.println(f.toString());
        }
        setAbismosHashMap();
        setFerramentasHashMap();
        setFerramentasDescricacao();
        return correct;
    }

    public void setFerramentasDescricacao(){
        for(Ferramenta f : this.ferramentasHashMap.values()){
            f.setDescricao();
        }
    }

    public void setAbismosHashMap(){
        for(Abismo a : this.abismos) {
            abismosHashMap.put(a.getPos(), a);
        }
    }

    public void setFerramentasHashMap(){
        for(Ferramenta ferramenta: this.ferramentas){
            ferramentasHashMap.put(ferramenta.getPos(),ferramenta);
        }
    }


    public String getTituloFerramenta(int id){
        switch (id) {
            case 0 -> {
                return "Herança";
            }
            case 1 -> {
                return "Programação funcional";
            }
            case 2 -> {
                return "Testes unitários";
            }
            case 3 -> {
                return "Tratamento de Excepções";
            }
            case 4 -> {
                return "IDE";
            }
            case 5 -> {
                return "Ajuda Do Professor";
            }
        }
        return "404";
    }


    public String getTituloAbismo(int id){
        switch (id) {
            case 0 -> {
                return "Erro de sintaxe";
            }
            case 1 -> {
                return "Erro de lógica";
            }
            case 2 -> {
                return "Exception";
            }
            case 3 -> {
                return "File Not Found Exception";
            }
            case 4 -> {
                return "Crash (aka Rebentanço)";
            }
            case 5 -> {
                return "Duplicated Code";
            }
            case 6 -> {
                return "Efeitos secundários";
            }
            case 7 -> {
                return "Blue Screen of Death";
            }
            case 8 -> {
                return "Ciclo infinito";
            }
            case 9 -> {
                return "Segmentation Fault";
            }
        }
        return "404";
    }


    public void orderPlayers(){
        int pos = 0;
        for(int pos1 = 0 ; pos1 < programmers.size() ; pos1++){
            for(int pos2 = 0 ; pos2 < programmers.size() ; pos2++){
                if(pos1 != pos2){
                    if(programmers.get(pos1).getId() >= programmers.get(pos2).getId()){
                        pos++;
                    }
                }
            }
            this.programmersTurn[pos] = programmers.get(pos1);
            pos = 0;
        }
        this.programmerTurnPos = 0;
    }

    public List<Programmer> getProgrammers(){ //TODO
        return this.programmers;
    }

    public List<Programmer> getProgrammers(boolean includeDefeated){
        List<Programmer> result = new ArrayList<Programmer>();
        if(includeDefeated){
            for(Programmer p : this.programmers){
                if(p.isEstado()){
                    result.add(p);
                }
            }
        }else{
            for(Programmer p : this.programmers){
                if(p.isEstado()){
                    result.add(p);
                }
            }
        }
        return result;
    }

    public List<Programmer> getProgrammers(int position){

        List<Programmer> result = new ArrayList<Programmer>();
        if(position <= 0){
            return null;
        }
        for(Programmer p : programmers){
            if(p.getPos() == position)
            {
                result.add(p);
            }
        }
        if(result.isEmpty()){
            return null;
        }
        return result;
    }

    public boolean moveCurrentPlayer(int nrPositions){
        System.out.println("ENTROU NO MOVE");
        this.nrTurnos++;
        if(nrPositions < 1 || nrPositions > 6){
            return false;
        }
        Programmer currentPlayer = programmersTurn[programmerTurnPos];
        if(currentPlayer.getPos() + nrPositions == this.boardSize) {
            this.playing = false;
            currentPlayer.move(nrPositions);
        }
        else if(currentPlayer.getPos() + nrPositions > this.boardSize)
        {
            currentPlayer.move((-(nrPositions - (this.boardSize - currentPlayer.getPos()) ) + this.boardSize ) - currentPlayer.getPos());

        }else{
            currentPlayer.move(nrPositions);
        }
        //reactToAbyssOrTool(); // NAO É SUPPOSTO SER AQUI O AVANÇO DE TURNO MAS SIM NO REACTTOABBYSANDTOOLS

        return true;
    }


    public String reactToAbyssOrTool(){
        String result = null;
        Programmer currentPlayer = programmersTurn[programmerTurnPos];
        int currentPlayerPos = currentPlayer.getPos();
        if(abismosHashMap.containsKey(currentPlayer.getPos())){
            Abismo a = abismosHashMap.get(currentPlayer.getPos());
            Ferramenta f = hasTool(currentPlayer, a);
            if(f == null){
                switch(a.getTitulo()){
                    case "Erro de sintaxe" ->{
                        currentPlayer.move(-1);
                        result = "O programador recua 1 casa.";
                        break;
                    }
                    case "Erro de lógica" ->{
                        currentPlayer.move(((currentPlayer.getPosicoesHistoria().get(currentPlayer.getPos())) -
                                (currentPlayer.getPosicoesHistoria().get(currentPlayer.getPosicoesHistoria().size() - 2))) / 2); //saber a posicao anterior
                        result = "ee";
                        break;
                    }
                    case "Exception" ->{
                        currentPlayer.move(-2);
                        result = "O programador recua 2 casas.";
                        break;
                    }
                    case "File Not Found Exception" ->{
                        currentPlayer.move(-3);
                        result = "O programador recua 3 casas.";
                        break;
                    }
                    case "Crash (aka Rebentanço)" ->{
                        currentPlayer.pos = 1;
                        result = "O programador volta à primeira casa do jogo.";
                        break;
                    }
                    case "Duplicated Code" ->{
                        currentPlayer.pos = currentPlayer.getPosicoesHistoria().get(currentPlayer.getPosicoesHistoria().size() - 2);
                        result = "O programador recua até à casa onde estava antes de chegar a esta casa.";
                        break;
                    }
                    case "Efeitos secundários"->{
                        currentPlayer.pos = currentPlayer.getPosicoesHistoria().get(currentPlayer.getPosicoesHistoria().size() - 3);
                        result = "O programador recua para a posição onde estava há 2 movimentos atrás.";
                        break;
                    }
                    case "Blue Screen of Death"->{
                        currentPlayer.perdeu();
                        result = "O programador perde imediatamente o jogo.";
                        break;
                    }
                    case "Segmentation Fault" ->{

                    }
                    case "Ciclo infinito" -> {

                    }
                }
            }else{
                //APAGAR FERRAMENTA
                currentPlayer.removeFerramenta(f);
            }
        }
        if(ferramentasHashMap.containsKey(currentPlayer.getPos())){
            Ferramenta ferramenta = ferramentasHashMap.get(currentPlayer.getPos());{
                switch (ferramenta.getTitulo()){
                    case "Herança" -> {
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem uma herança";
                        break;
                    }
                    case "Programação funcional" ->{
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem um programa funcional";
                        break;
                    }
                    case "Testes unitários" -> {
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem um teste unitário";
                        break;
                    }
                    case "Tratamento de Excepções" -> {
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem um Tratamento de Excepções";
                        break;
                    }
                    case "IDE" -> {
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem um IDE";
                        break;
                    }
                    case "Ajuda Do Professor" -> {
                        currentPlayer.addFerramenta(ferramentasHashMap.get(currentPlayerPos));
                        result = "O simoes tem Ajuda Do Professor";
                        break;
                    }
                }
            }
        }

        setNextPlayer();
        return result;
    }

    public Ferramenta hasTool(Programmer currentPlayer, Abismo a) {
        HashMap<String,Ferramenta> fs =  currentPlayer.getFerramentas();
        switch (a.getTitulo()) {
            case "Erro de sintaxe" -> {
                if(fs.containsKey("Ajuda Do Professor")){
                    return fs.get("Ajuda do Professor");
                }else if(fs.containsKey("IDE")){
                    return fs.get("IDE");
                }
            }
            case "Erro de lógica" -> {
                if(fs.containsKey("Ajuda Do Professor")){
                    return fs.get("Ajuda do Professor");
                }
            }
            case "Exception" -> {
                if(fs.containsKey("Ajuda Do Professor")){
                    return fs.get("Ajuda do Professor");
                }else if(fs.containsKey("Tratamento de Excepções")){
                    return fs.get("Tratamento de Excepções");
                }
            }
            case "File Not Found Exception" -> {
                if(fs.containsKey("Ajuda Do Professor")){
                    return fs.get("Ajuda do Professor");
                }else if (fs.containsKey("Tratamento de Excepções")){
                    return fs.get("Tratamento de Excepções");
                }
            }
            case "Crash (aka Rebentanço)" -> {
                if(fs.containsKey("Testes unitários")) {
                    return fs.get("Testes unitários");
                }
            }
            case "Duplicated Code" -> {
                if(fs.containsKey("Herança")){
                    return fs.get("Herança");
                }
            }
            case "Efeitos secundários" -> {
                if(fs.containsKey("Programação Funcional")){
                    return fs.get("Programação Funcional ");
                }
            }
            case "Blue Screen of Death" -> {

            }
            case "Segmentation Fault" -> {

            }
            case "Ciclo infinito" -> {

            }
        }
        return null;
    }

    public void setNextPlayer(){
        if(programmerTurnPos + 1 >= this.programmersTurn.length){
            programmerTurnPos = 0;

        }else{
            programmerTurnPos++;
        }
    }

    public int getCurrentPlayerID(){

        return programmersTurn[programmerTurnPos].id;
    }

    public Programmer getCurrentPlayerByID(int id){
        for(Programmer p : programmers){
            if(p.getId() == id){
                return p;
            }
        }
        return null;
    }

    public boolean gameIsOver(){
        return !this.playing;
    }


    public String getImagePng(int position){
        System.out.println(position);
        if(position > this.boardSize || position <= 0){
            return null;
        }
        if(position == this.boardSize){
            return "glory.png";
        }



        List<Programmer> programmersInPos = getProgrammers(position);


        if(programmersInPos != null){

            ProgrammerColor c = programmersInPos.get(0).getColor();
            if(c != null){
                switch (c) {
                    case BLUE -> {
                        return "playerBlue.png";
                    }
                    case GREEN -> {
                        return "playerGreen.png";
                    }
                    case BROWN -> {
                        return "playerBrown.png";
                    }
                    case PURPLE-> {
                        return "playerPurple.png";
                    }
                }
            }
        }

        if(!abismosHashMap.containsKey(position) && !ferramentasHashMap.containsKey(position)){
            return null;
        }
        if(abismosHashMap.containsKey(position)){
            String t = abismosHashMap.get(position).getTitulo();
            switch(t){
                case "Erro de sintaxe" ->{
                    return "syntax.png";
                }
                case "Erro de lógica" -> {
                    return "logic.png";
                }
                case "Exception" -> {
                    return "exception.png";
                }
                case "File Not Found Exception" -> {
                    return "file-not-found-exception.png";
                }
                case "Crash (aka Rebentanço)" -> {
                    return "crash.png";
                }
                case "Duplicated Code" -> {
                    return "duplicated-code.png";
                }
                case "Efeitos secundários" -> {
                    return "secondary-effects.png";
                }
                case "Blue Screen of Death" -> {
                    return "bsod.png";
                }
                case "Ciclo infinito" -> {
                    return "infinite-loop.png";
                }
                case "Segmentation Fault" -> {
                    return "core-dumped.png";
                }
            }
        }else if(ferramentasHashMap.containsKey(position)){
            String ferramentasTitulo = ferramentasHashMap.get(position).getTitulo();
            switch (ferramentasTitulo){
                case "Herança" -> {
                    return "inheritance.png";
                }
                case "Programação funcional" -> {
                    return "functional.png";
                }
                case "Testes unitários" -> {
                    return "unit-tests.png";
                }
                case "Tratamento de Excepções" -> {
                    return "exception.png";
                }
                case "IDE" -> {
                    return "IDE.png";
                }
                case "Ajuda Do Professor" -> {
                    return "ajuda-professor.png";
                }
            }
        }


        return "blank.png";
    }



    public List<String> getGameResults(){
        ArrayList<String> result = new ArrayList<>();
        result.add("O GRANDE JOGO DO DEISI");
        result.add("");
        result.add("NR. DE TURNOS");
        result.add(""+this.nrTurnos);
        result.add("");


        Programmer[] resultOrder = new Programmer[this.programmersTurn.length];


        int pos = 0;

        for(Programmer  p : this.programmersTurn){
            for(Programmer pCompare : this.programmersTurn){
                if(p.getPos() >= pCompare.getPos()){

                }else{
                    pos++;
                }
            }
            //resultOrder[pos] = p;
            if(resultOrder[pos] == null)
            {
                resultOrder[pos] = p;
            }
            else if(pos-1 >= 0 && resultOrder[pos-1] == null)
            {
                resultOrder[pos-1] = p;
            }else if(pos+1 < resultOrder.length && resultOrder[pos+1] == null){
                resultOrder[pos+1] = p;
            }else{
                resultOrder[pos] = p;
            }
            pos = 0;
        }

        for(int i = 0; i < resultOrder.length ; i++){
            Programmer p = resultOrder[i];
            switch(i){
                case 0:{
                    result.add("VENCEDOR");
                    result.add(p.getName());
                    result.add("");
                    result.add("RESTANTES");
                    break;
                }
                default:{
                    if (p != null){
                        result.add(p.getName() + " " + p.pos);
                    }
                    //result.add("\n"); ver se é diferente de null
                }
            }
        }
        return result;
    }

    public JPanel getAuthorsPanel(){
        //v1
        JPanel panel = new JPanel();
        JLabel jlabel = new JLabel("Pedro brito a21903302");
        JLabel jlabel2 = new JLabel("Joao luis a21903149");
        jlabel.setFont(new Font("Verdana",1,20));
        jlabel2.setFont(new Font("Verdana",1,20));
        panel.add(jlabel);
        panel.add(jlabel2);
        panel.setSize(300,300);
        return panel;

    }


    public String getProgrammersInfo(){
        String r = "";
        for(Programmer p : this.programmers){
            r += p.getName() + " : ";
            if(!p.getFerramentas().isEmpty()){
                for(Ferramenta f : p.getFerramentas().values()){
                    r += f.getDescricao();
                }
            }else{
                r += "No tools";
            }
            r += " | ";
        }
        return r;
    }


    public String getTitle(int position){
        if(abismosHashMap.containsKey(position)){
            return abismosHashMap.get(position).getTitulo();
        }
        if(ferramentasHashMap.containsKey(position)){
            return ferramentasHashMap.get(position).getTitulo();
        }
        return null;
    }
}
