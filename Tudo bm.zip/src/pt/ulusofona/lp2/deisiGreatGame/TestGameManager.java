package pt.ulusofona.lp2.deisiGreatGame;
import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;


public class TestGameManager {

    GameManager gm = new GameManager();
    String[][] board = {{"0","Pedro","Java","Purple"},{"1","Mariza","Kotlin","Green"},{"2","Joao","C","Brown"}};
/*
    @Test
    public void testCreateInitialBoard(){
        Assert.assertTrue(gm.createInitialBoard(board,40));

        Assert.assertFalse(gm.createInitialBoard(board, 2));


    }

    @Test
    public void testGetProgrammers(){
        gm.createInitialBoard(board, 40);
        ArrayList<Programmer> resultExpected = new ArrayList<Programmer>();

        Programmer p = new Programmer();
        p.setName("Pedro");
        ArrayList<String> ling = new ArrayList<String>();
        ling.add("Java");
        p.setLinguages(ling);
        p.setColor(ProgrammerColor.PURPLE);
        p.setId(0);
        resultExpected.add(p);

        Programmer pMarisza = new Programmer();
        pMarisza.setName("Mariza");
        ArrayList<String> lingMariza = new ArrayList<String>();
        lingMariza.add("Kotlin");
        pMarisza.setLinguages(lingMariza);
        pMarisza.setColor(ProgrammerColor.GREEN);
        pMarisza.setId(1);
        resultExpected.add(pMarisza);

        Programmer pJoao = new Programmer();
        pJoao.setName("Joao");
        ArrayList<String> lingJoao = new ArrayList<String>();
        lingJoao.add("C");
        pJoao.setLinguages(lingJoao);
        pJoao.setColor(ProgrammerColor.BROWN);
        pJoao.setId(2);
        resultExpected.add(pJoao);

        Assert.assertFalse(resultExpected.equals(gm.getProgrammers()));
        //Assert.assertEquals(resultExpected, gm.getProgrammers());
        //Assert.assertEquals(resultExpected, gm.getProgrammers());
    }


    @Test
    public void testMoveCurrentPlayer(){
        gm.createInitialBoard(board, 40);
        ArrayList<Programmer> result = gm.getProgrammers();
        Programmer p = gm.getCurrentPlayerByID(0);
        int pos = p.getPos();
        Assert.assertEquals(result.get(0),p);
        gm.moveCurrentPlayer(3);
        Assert.assertEquals(pos + 3 , p.getPos());

        Assert.assertFalse(gm.moveCurrentPlayer(-3));
        Assert.assertFalse(gm.moveCurrentPlayer(9));
    }

    @Test
    public void getCurrentPlayerByID(){
        gm.createInitialBoard(board, 40);
        ArrayList<Programmer> result = gm.getProgrammers();
        Programmer p = gm.getCurrentPlayerByID(0);
        Assert.assertEquals(result.get(0),p);

    }

 */

}
